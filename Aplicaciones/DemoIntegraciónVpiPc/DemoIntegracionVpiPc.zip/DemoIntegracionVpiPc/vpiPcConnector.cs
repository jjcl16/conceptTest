﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace DemoIntegracionVpiPc
{
    public class vpiPcConnector
    {
        //vpiOpenPort -> Abrir puerto
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiOpenPort(ref comParams_t comParams);

        //vpiClosePort -> Cerrar puerto
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiClosePort();

        //vpiTestConnection -> Test de comunicación
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiTestConnection();

        //vpiPurchaseMark -> Venta
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiPurchaseMark( ref vpiPurchaseIn_t input,  ref vpiTrxMarkOut1_t output, ulong timeout);

        //vpiPurchaseExtraCashMark -> Venta + Extracción
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiPurchaseExtraCashMark(ref vpiPurchaseIn_t input, ref vpiTrxMarkOut1_t output, ulong timeout);

        //vpiGetQRZ -> Venta con QR
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiGetQRZ(ref vpiQrzIn_t input, ref vpiQrzOut_t output, ulong timeout);

        //vpiVoid -> Anulacion
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiVoid(ref vpiVoidIn_t input, ref vpiTrxOut_t output, ulong timeout);

        //vpiRefund -> Devolución
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiRefund(ref vpiRefundIn_t input, ref vpiTrxOut_t output, ulong timeout);

        //vpiBatchClose -> Cierre de lote
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiBatchClose(ref vpiBatchCloseOut_t output, ulong timeout);

        //vpiGetLastTrxData -> Consulta de ultima transacción aprobada
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiGetLastTrxData(ref uint trxCode, ref vpiTrxOut_t output);

        //vpiGetBatchCloseData -> Consulta de ultimo lote cerrado
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiGetBatchCloseData(uint index, ref vpiBatchCloseDataOut_t output);

        //vpiGetIssuer -> Consulta de tarjetas
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiGetIssuer(uint index, ref vpiIssuerOut_t output);

        //vpiGetPlan -> Consulta de planes
        [DllImport("VpiPc.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern int vpiGetPlan(uint index, ref vpiPlanOut_t output);

    }


    /*
     Estructuras de entrada y salida
     */

    // struct comParams_t
    public struct comParams_t
    {
        public string com;          // Nombre del puerto. Ej: "COM1", "COM2", etc.
        public ushort baudRate;     // Velocidad de transmición: 19200
        public ushort byteSize;     // Largo del byte: 8
        public char parity;         // Paridad: 'N'
        public ushort stopBits;     // Bits de parada: 1
    }

    //struct vpiPurchaseIn_t
    public struct vpiPurchaseIn_t
    {
        public string amount;           // Monto x100  
        public string receiptNumber;    // Número de factura  
        public string instalmentCount;  // Cant. de cuotas  
        public string issuerCode;       // Código de tarjeta  
        public string planCode;         // Código de plan  
        public string tip;              // Propina x100
        public string merchantCode;     // Código de comercio a utilizar
        public string merchantName;     // Razón social del comercio
        public string cuit;             // CUIT del comercio
        public char linemode;                  // online 1
    }

    //struct TrxMarkOut
    public struct vpiTrxMarkOut1_t
    {
        public string hostRespCode;     // Código de respuesta del host   
        public string hostMessage;      // Mensaje de respuesta del host   
        public string authCode;         // Número de autorización   
        public string ticketNumber;     // Número de cupón   
        public string batchNumber;      // Número de lote   
        public string customerName;     // Nombre del tarjeta-habiente   
        public string panLast4;         // Ultimo 4 digitos de la tarjeta   
        public string panFirst6;        // Primeros 6 digitos de la tarjeta	
        public string date;             // Fecha de la transacción (DD/MM/AAAA)  
        public string time;             // Hora de la transaccion (HH:MM:SS)
        public string terminalID;       // Número de Terminal
        public string issuerCode;       // Código de tarjeta
        public string merchantCode;     // Código de comercio
        public string aipEmv;           // Aip para EMV
        public string appEmv;           // App para EMV
        public string promoMsg;         // Mensaje promocional
    }

    //struct vpiQrzIn_t
    public struct vpiQrzIn_t 
    {
        public string ammount;      // Monto x100  
        public string cantCoutas;   // Cantida de cuotas  
        public string planCod;      // Código de plan     
    }

    //struct vpiQrzOut_t
    public struct vpiQrzOut_t
    {
        public string respcode;         //Código de respuesta del host.
        public string respMsg;          //Mensaje de respuesta. 
        public string authCode;          //Código de autorización   
        public string cuponNmb;         //Número de cupón
        public string loteNmb;          //Número de lote.
        public string lastFour;         //Últimos 4 dígitos de la tarjeta.
        public string firstSix;         //Primeros 6 dígitos de la tarjeta.
        public string trxDate;          //Fecha de la transacción(“DD / MM / AAAA”).
        public string trxHr;            //Hora de la transacción(“HH:MM:SS”).
        public string terminalID;       //Terminal id.
        public string cardCod;          //Código de Tarjeta.
        public string impTotal;         //Importe Total
        public string impCobrado;       //Importe cobrado
    }

    //struct vpiVoidIn_t
    public struct vpiVoidIn_t
    {
        public string originalTicket;   // Número de cupón de trx. original  
        public string issuerCode;       // Código de tarjeta
        public string merchantName;     // Razón social del comercio
        public string cuit;             // CUIT del comercio
    }

    //truct vpiRefundIn_t
    public struct vpiRefundIn_t
    {
        public string amount;           // Monto *100  
        public string instalmentCount;  // Cant. de cuotas  
        public string issuerCode;       // Código de tarjeta
        public string planCode;         // Código de plan
        public string originalTicket;   // Nro. ticket de la trx. original
        public string originalDate;     // Fecha de la trx. original
        public string receiptNumber;    // Número de factura 
        public string merchantCode;     // Código de comercio a utilizar
        public string merchantName;     // Razon social del comercio
        public string cuit;             // CUIT del comercio
        public char linemode;                  // transaccion Online(1)
    }

    //struct vpiTrxOut_t
    public struct vpiTrxOut_t
    {
        public string hostRespCode; // Código de respuesta del host   
        public string hostMessage;  // Mensaje de respuesta del host   
        public string authCode;     // Número de autorización   
        public string ticketNumber; // Número de cupón   
        public string batchNumber;  // Número de lote   
        public string customerName; // Nombre del tarjeta-habiente
        public string panFirst6;    // Primeros 6 digitos de la tarjeta
        public string panLast4;     // Últimos 4 digitos de la tarjeta   
        public string date;         // Fecha de la transacción (DD/MM/AAAA)  
        public string time;         // Hora de la transacción (HH:MM:SS)
        public string terminalID;   // Terminal id
    }

    //struc vpiBatchCloseOut_t
    public struct vpiBatchCloseOut_t
    {
        public string hostRespCode; // Código de respuesta del host  
        public string date;         // Fecha ("DD/MM/AAAA")  
        public string time;         // Hora ("HH:MM:SS")
        public string terminalID;   // Terminal id
    }

    //struct vpiBatchCloseDataOut_t
    public struct vpiBatchCloseDataOut_t
    {
        public uint index;              // Índice del registro.   
        public string acquirerCode;     // Código de procesador.   
        public string batchNumber;      // Número de lote.   
        public string issuerCode;       // Código de tarjeta   
        public string purchaseCount;    // Cantidad de ventas.   
        public string purchaseAmount;   // Monto total de ventas.   
        public string voidCount;        // Cantidad anulaciones de venta.   
        public string voidAmount;       // Monto total de anulaciones.   
        public string refundCount;      // Cantidad de devoluciones venta.   
        public string refundAmount;     // Monto total de devoluciones.   
        public string refvoidCount;     // Cantidad anulaciones devolución.   
        public string refvoidAmount;    // Monto total anul. devolución.
        public string date;             // Fecha ("DD/MM/AAAA")  
        public string time;             // Hora ("HH:MM:SS")
        public string terminalID;       // Terminal id
    }

    //struct vpiIssuerOut_t
    public struct vpiIssuerOut_t
    {
        public uint index;             // Índice del registro.	 
        public string acquirerCode;     // Código de procesador.   
        public string issuerCode;       // Código de tarjeta   
        public string issuerName;       // Nombre de la tarjeta   
        public string maxInstCount;     // Maxima cantidad de cuotas
        public string terminalID;       // Terminal id
    }

    //struct vpiPlanOut_t
    public struct vpiPlanOut_t
    {
        public uint   index;        //Índice del registro.
        public string issuerCode;   //Código de tarjeta   
        public string planCode;     //Código de plan   
        public string planLabel;    //Nombre del plan
        public string terminalID;   // Terminal id
    }

    /**
* Codigos de retorno de las funciones
*/
    public class responseValues
    {
        public const int VPI_OK                 = 0;    // Comando procesado
        public const int VPI_MORE_REC           = 1;    // Comando procesado, pero faltan registros
        public const int VPI_FAIL               = 11;   // El comando no pudo ser enviado
        public const int VPI_TIMEOUT_EXP        = 12;   // Tiempo de espera agotado.
        public const int VPI_INVALID_ISSUER     = 101;  // El código de tarjeta no existe.
        public const int VPI_INVALID_TICKET     = 102;  // El número de cupón no existe.
        public const int VPI_INVALID_PLAN       = 103;  // El código de plan no existe.
        public const int VPI_INVALID_INDEX      = 104;  // No existe el indice
        public const int VPI_EMPTY_BATCH        = 105;  // El lote del POS se encuentra vacío.
        public const int VPI_TRX_CANCELED       = 201;  // Transacción cancelada por el usuario.
        public const int VPI_DIF_CARD           = 202;  // La tarjeta deslizada por el usuario no coincide con la pedida.
        public const int VPI_INVALID_CARD       = 203;  // La tarjeta deslizada no es válida.
        public const int VPI_EXPIRED_CARD       = 204;  // La tarjeta deslizada está vencida.
        public const int VPI_INVALID_TRX        = 205;  // La transacción original no existe. 
        public const int VPI_BATCH_EMPTY        = 206;  // Lote Vacío.
        public const int VPI_ERR_COM            = 301;  // El POS no pudo comunicarse con el host.
        public const int VPI_ERR_PRINT          = 302;  // El POS no pudo imprimir el ticket.
        public const int VPI_INVALID_IN_CMD     = 901;  // Nombre del comando inexistente.
        public const int VPI_INVALID_IN_PARAM   = 902;  // Formato de algún parámetro de entrada no es correcto.
        public const int VPI_INVALID_OUT_CMD    = 903;  // El comando enviado por
        public const int VPI_GENERAL_FAIL       = 909;  // Error general en la operación.
    }

}
