﻿using System.Collections.Generic;
using System.Linq;

namespace DemoIntegracionVpiPc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            portSelectBox = new ComboBox();
            ComButton = new Button();
            comTestButton = new Button();
            updateComPorts = new Button();
            comandsGroupBox = new GroupBox();
            commandsTabs = new TabControl();
            ventaTab = new TabPage();
            groupBox4 = new GroupBox();
            label6 = new Label();
            planQrTBox = new TextBox();
            amountQrTBox = new TextBox();
            instQrTBox = new NumericUpDown();
            label8 = new Label();
            label9 = new Label();
            qrButton = new Button();
            groupBox3 = new GroupBox();
            cardCodPurchaseTBox = new TextBox();
            label4 = new Label();
            label3 = new Label();
            Extracash = new GroupBox();
            extracashTBox = new TextBox();
            extracashButton = new Button();
            label5 = new Label();
            planPurchaseTBox = new TextBox();
            purchaseButton = new Button();
            amountPurchaseTBox = new TextBox();
            label1 = new Label();
            InstPurchaseTBox = new NumericUpDown();
            label2 = new Label();
            anvTab = new TabPage();
            groupBox5 = new GroupBox();
            batchButton = new Button();
            groupBox2 = new GroupBox();
            label16 = new Label();
            textBox1 = new TextBox();
            ticketNumberTBox = new NumericUpDown();
            label15 = new Label();
            label11 = new Label();
            planDevTBox = new TextBox();
            cardDevTBox = new TextBox();
            amountDevTBox = new TextBox();
            label12 = new Label();
            instalDevTBox = new NumericUpDown();
            label13 = new Label();
            label14 = new Label();
            devButton = new Button();
            groupBox1 = new GroupBox();
            label7 = new Label();
            codCardVoidTBox = new TextBox();
            ticketNmbTBox = new NumericUpDown();
            label10 = new Label();
            voidButton = new Button();
            consultasTab = new TabPage();
            getLastTrxButton = new Button();
            getPlansButton = new Button();
            lastBatchButton = new Button();
            cardsButton = new Button();
            contextMenuStrip1 = new ContextMenuStrip(components);
            outputTextBox = new RichTextBox();
            getVersionButton = new Button();
            comandsGroupBox.SuspendLayout();
            commandsTabs.SuspendLayout();
            ventaTab.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)instQrTBox).BeginInit();
            groupBox3.SuspendLayout();
            Extracash.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)InstPurchaseTBox).BeginInit();
            anvTab.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ticketNumberTBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)instalDevTBox).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ticketNmbTBox).BeginInit();
            consultasTab.SuspendLayout();
            SuspendLayout();
            // 
            // portSelectBox
            // 
            portSelectBox.FormattingEnabled = true;
            portSelectBox.Items.AddRange(new object[] { "COM7" });
            portSelectBox.Location = new Point(555, 12);
            portSelectBox.Name = "portSelectBox";
            portSelectBox.Size = new Size(83, 23);
            portSelectBox.TabIndex = 0;
            portSelectBox.Text = "Puerto";
            // 
            // ComButton
            // 
            ComButton.Location = new Point(644, 12);
            ComButton.Name = "ComButton";
            ComButton.Size = new Size(75, 23);
            ComButton.TabIndex = 1;
            ComButton.Text = "Abrir";
            ComButton.UseVisualStyleBackColor = true;
            ComButton.Click += ComButton_Click;
            // 
            // comTestButton
            // 
            comTestButton.Enabled = false;
            comTestButton.Location = new Point(445, 39);
            comTestButton.Name = "comTestButton";
            comTestButton.Size = new Size(274, 23);
            comTestButton.TabIndex = 2;
            comTestButton.Text = "Prueba de comunicación";
            comTestButton.UseVisualStyleBackColor = true;
            comTestButton.Click += comTestButton_Click;
            // 
            // updateComPorts
            // 
            updateComPorts.Location = new Point(445, 12);
            updateComPorts.Name = "updateComPorts";
            updateComPorts.Size = new Size(104, 23);
            updateComPorts.TabIndex = 3;
            updateComPorts.Text = "Act. Lista COM";
            updateComPorts.UseVisualStyleBackColor = true;
            updateComPorts.Click += updateComPorts_Click;
            // 
            // comandsGroupBox
            // 
            comandsGroupBox.Controls.Add(commandsTabs);
            comandsGroupBox.Location = new Point(4, 3);
            comandsGroupBox.Name = "comandsGroupBox";
            comandsGroupBox.Size = new Size(435, 384);
            comandsGroupBox.TabIndex = 6;
            comandsGroupBox.TabStop = false;
            comandsGroupBox.Text = "Comandos";
            // 
            // commandsTabs
            // 
            commandsTabs.Controls.Add(ventaTab);
            commandsTabs.Controls.Add(anvTab);
            commandsTabs.Controls.Add(consultasTab);
            commandsTabs.Location = new Point(0, 22);
            commandsTabs.Name = "commandsTabs";
            commandsTabs.SelectedIndex = 0;
            commandsTabs.Size = new Size(429, 356);
            commandsTabs.TabIndex = 5;
            // 
            // ventaTab
            // 
            ventaTab.Controls.Add(groupBox4);
            ventaTab.Controls.Add(groupBox3);
            ventaTab.Enabled = false;
            ventaTab.Location = new Point(4, 24);
            ventaTab.Name = "ventaTab";
            ventaTab.Padding = new Padding(3);
            ventaTab.Size = new Size(421, 328);
            ventaTab.TabIndex = 0;
            ventaTab.Text = "Ventas";
            ventaTab.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(label6);
            groupBox4.Controls.Add(planQrTBox);
            groupBox4.Controls.Add(amountQrTBox);
            groupBox4.Controls.Add(instQrTBox);
            groupBox4.Controls.Add(label8);
            groupBox4.Controls.Add(label9);
            groupBox4.Controls.Add(qrButton);
            groupBox4.Location = new Point(6, 186);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(409, 136);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "Ventas QR";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(162, 78);
            label6.Name = "label6";
            label6.Size = new Size(30, 15);
            label6.TabIndex = 29;
            label6.Text = "Plan";
            // 
            // planQrTBox
            // 
            planQrTBox.Location = new Point(162, 96);
            planQrTBox.MaxLength = 1;
            planQrTBox.Name = "planQrTBox";
            planQrTBox.Size = new Size(30, 23);
            planQrTBox.TabIndex = 28;
            planQrTBox.Text = "0";
            planQrTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // amountQrTBox
            // 
            amountQrTBox.Location = new Point(78, 44);
            amountQrTBox.MaxLength = 12;
            amountQrTBox.Name = "amountQrTBox";
            amountQrTBox.Size = new Size(105, 23);
            amountQrTBox.TabIndex = 24;
            amountQrTBox.Text = "525000";
            amountQrTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // instQrTBox
            // 
            instQrTBox.Location = new Point(78, 96);
            instQrTBox.Maximum = new decimal(new int[] { 99, 0, 0, 0 });
            instQrTBox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            instQrTBox.Name = "instQrTBox";
            instQrTBox.Size = new Size(44, 23);
            instQrTBox.TabIndex = 27;
            instQrTBox.TextAlign = HorizontalAlignment.Center;
            instQrTBox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(78, 78);
            label8.Name = "label8";
            label8.Size = new Size(44, 15);
            label8.TabIndex = 26;
            label8.Text = "Cuotas";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(112, 26);
            label9.Name = "label9";
            label9.Size = new Size(43, 15);
            label9.TabIndex = 25;
            label9.Text = "Monto";
            // 
            // qrButton
            // 
            qrButton.Location = new Point(229, 63);
            qrButton.Name = "qrButton";
            qrButton.Size = new Size(96, 30);
            qrButton.TabIndex = 23;
            qrButton.Text = "Generar QR";
            qrButton.UseVisualStyleBackColor = true;
            qrButton.Click += qrButton_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(cardCodPurchaseTBox);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(Extracash);
            groupBox3.Controls.Add(planPurchaseTBox);
            groupBox3.Controls.Add(purchaseButton);
            groupBox3.Controls.Add(amountPurchaseTBox);
            groupBox3.Controls.Add(label1);
            groupBox3.Controls.Add(InstPurchaseTBox);
            groupBox3.Controls.Add(label2);
            groupBox3.Location = new Point(6, 6);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(409, 174);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Ventas Tarjeta presente";
            // 
            // cardCodPurchaseTBox
            // 
            cardCodPurchaseTBox.Location = new Point(117, 83);
            cardCodPurchaseTBox.MaxLength = 3;
            cardCodPurchaseTBox.Name = "cardCodPurchaseTBox";
            cardCodPurchaseTBox.Size = new Size(50, 23);
            cardCodPurchaseTBox.TabIndex = 10;
            cardCodPurchaseTBox.Text = "VVI";
            cardCodPurchaseTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(31, 114);
            label4.Name = "label4";
            label4.Size = new Size(30, 15);
            label4.TabIndex = 13;
            label4.Text = "Plan";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(94, 65);
            label3.Name = "label3";
            label3.Size = new Size(98, 15);
            label3.TabIndex = 11;
            label3.Text = "Código de tarjeta";
            // 
            // Extracash
            // 
            Extracash.Controls.Add(extracashTBox);
            Extracash.Controls.Add(extracashButton);
            Extracash.Controls.Add(label5);
            Extracash.Location = new Point(240, 22);
            Extracash.Name = "Extracash";
            Extracash.Size = new Size(163, 140);
            Extracash.TabIndex = 17;
            Extracash.TabStop = false;
            Extracash.Text = "Extracash";
            // 
            // extracashTBox
            // 
            extracashTBox.Location = new Point(36, 50);
            extracashTBox.MaxLength = 12;
            extracashTBox.Name = "extracashTBox";
            extracashTBox.Size = new Size(100, 23);
            extracashTBox.TabIndex = 15;
            extracashTBox.Text = "6500000";
            extracashTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // extracashButton
            // 
            extracashButton.Location = new Point(6, 90);
            extracashButton.Name = "extracashButton";
            extracashButton.Size = new Size(151, 30);
            extracashButton.TabIndex = 14;
            extracashButton.Text = "Venta + Extracción";
            extracashButton.UseVisualStyleBackColor = true;
            extracashButton.Click += extracashButton_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(28, 32);
            label5.Name = "label5";
            label5.Size = new Size(117, 15);
            label5.TabIndex = 16;
            label5.Text = "Monto de extracción";
            // 
            // planPurchaseTBox
            // 
            planPurchaseTBox.Location = new Point(31, 132);
            planPurchaseTBox.MaxLength = 1;
            planPurchaseTBox.Name = "planPurchaseTBox";
            planPurchaseTBox.Size = new Size(30, 23);
            planPurchaseTBox.TabIndex = 12;
            planPurchaseTBox.Text = "0";
            planPurchaseTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // purchaseButton
            // 
            purchaseButton.Location = new Point(117, 125);
            purchaseButton.Name = "purchaseButton";
            purchaseButton.Size = new Size(75, 30);
            purchaseButton.TabIndex = 4;
            purchaseButton.Text = "Venta";
            purchaseButton.UseVisualStyleBackColor = true;
            purchaseButton.Click += purchaseButton_Click;
            // 
            // amountPurchaseTBox
            // 
            amountPurchaseTBox.Location = new Point(48, 33);
            amountPurchaseTBox.MaxLength = 12;
            amountPurchaseTBox.Name = "amountPurchaseTBox";
            amountPurchaseTBox.Size = new Size(100, 23);
            amountPurchaseTBox.TabIndex = 5;
            amountPurchaseTBox.Text = "525000";
            amountPurchaseTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(77, 15);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 6;
            label1.Text = "Monto";
            // 
            // InstPurchaseTBox
            // 
            InstPurchaseTBox.Location = new Point(31, 83);
            InstPurchaseTBox.Maximum = new decimal(new int[] { 99, 0, 0, 0 });
            InstPurchaseTBox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            InstPurchaseTBox.Name = "InstPurchaseTBox";
            InstPurchaseTBox.Size = new Size(44, 23);
            InstPurchaseTBox.TabIndex = 9;
            InstPurchaseTBox.TextAlign = HorizontalAlignment.Center;
            InstPurchaseTBox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(31, 65);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 8;
            label2.Text = "Cuotas";
            // 
            // anvTab
            // 
            anvTab.Controls.Add(groupBox5);
            anvTab.Controls.Add(groupBox2);
            anvTab.Controls.Add(groupBox1);
            anvTab.Enabled = false;
            anvTab.Location = new Point(4, 24);
            anvTab.Name = "anvTab";
            anvTab.Padding = new Padding(3);
            anvTab.Size = new Size(421, 328);
            anvTab.TabIndex = 5;
            anvTab.Text = " Anulación, Devolución y Cierre";
            anvTab.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(batchButton);
            groupBox5.Location = new Point(6, 255);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(409, 70);
            groupBox5.TabIndex = 2;
            groupBox5.TabStop = false;
            groupBox5.Text = "Cierre de Lote";
            // 
            // batchButton
            // 
            batchButton.Location = new Point(137, 26);
            batchButton.Name = "batchButton";
            batchButton.Size = new Size(122, 29);
            batchButton.TabIndex = 0;
            batchButton.Text = "Cierre de Lote";
            batchButton.UseVisualStyleBackColor = true;
            batchButton.Click += batchButton_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label16);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(ticketNumberTBox);
            groupBox2.Controls.Add(label15);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(planDevTBox);
            groupBox2.Controls.Add(cardDevTBox);
            groupBox2.Controls.Add(amountDevTBox);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(instalDevTBox);
            groupBox2.Controls.Add(label13);
            groupBox2.Controls.Add(label14);
            groupBox2.Controls.Add(devButton);
            groupBox2.Location = new Point(170, 6);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(245, 249);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Devolución";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(145, 69);
            label16.Name = "label16";
            label16.Size = new Size(88, 15);
            label16.TabIndex = 31;
            label16.Text = " Fecha Trx. Org.";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(139, 86);
            textBox1.MaxLength = 12;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 30;
            textBox1.Text = "dd/mm/aaaa";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // ticketNumberTBox
            // 
            ticketNumberTBox.Location = new Point(10, 87);
            ticketNumberTBox.Maximum = new decimal(new int[] { 9999, 0, 0, 0 });
            ticketNumberTBox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            ticketNumberTBox.Name = "ticketNumberTBox";
            ticketNumberTBox.Size = new Size(86, 23);
            ticketNumberTBox.TabIndex = 29;
            ticketNumberTBox.TextAlign = HorizontalAlignment.Center;
            ticketNumberTBox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(18, 69);
            label15.Name = "label15";
            label15.Size = new Size(72, 15);
            label15.TabIndex = 28;
            label15.Text = " Cupón Org.";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(193, 125);
            label11.Name = "label11";
            label11.Size = new Size(30, 15);
            label11.TabIndex = 22;
            label11.Text = "Plan";
            // 
            // planDevTBox
            // 
            planDevTBox.Location = new Point(193, 143);
            planDevTBox.MaxLength = 1;
            planDevTBox.Name = "planDevTBox";
            planDevTBox.Size = new Size(30, 23);
            planDevTBox.TabIndex = 21;
            planDevTBox.Text = "0";
            planDevTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // cardDevTBox
            // 
            cardDevTBox.Location = new Point(31, 143);
            cardDevTBox.MaxLength = 3;
            cardDevTBox.Name = "cardDevTBox";
            cardDevTBox.Size = new Size(48, 23);
            cardDevTBox.TabIndex = 19;
            cardDevTBox.Text = "0VI";
            cardDevTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // amountDevTBox
            // 
            amountDevTBox.Location = new Point(74, 37);
            amountDevTBox.MaxLength = 12;
            amountDevTBox.Name = "amountDevTBox";
            amountDevTBox.Size = new Size(100, 23);
            amountDevTBox.TabIndex = 15;
            amountDevTBox.Text = "525000";
            amountDevTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(10, 124);
            label12.Name = "label12";
            label12.Size = new Size(98, 15);
            label12.TabIndex = 20;
            label12.Text = "Código de tarjeta";
            // 
            // instalDevTBox
            // 
            instalDevTBox.Location = new Point(130, 142);
            instalDevTBox.Maximum = new decimal(new int[] { 99, 0, 0, 0 });
            instalDevTBox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            instalDevTBox.Name = "instalDevTBox";
            instalDevTBox.Size = new Size(44, 23);
            instalDevTBox.TabIndex = 18;
            instalDevTBox.TextAlign = HorizontalAlignment.Center;
            instalDevTBox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(130, 124);
            label13.Name = "label13";
            label13.Size = new Size(44, 15);
            label13.TabIndex = 17;
            label13.Text = "Cuotas";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(102, 19);
            label14.Name = "label14";
            label14.Size = new Size(43, 15);
            label14.TabIndex = 16;
            label14.Text = "Monto";
            // 
            // devButton
            // 
            devButton.Location = new Point(82, 197);
            devButton.Name = "devButton";
            devButton.Size = new Size(75, 30);
            devButton.TabIndex = 14;
            devButton.Text = "Devolver";
            devButton.UseVisualStyleBackColor = true;
            devButton.Click += devButton_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(codCardVoidTBox);
            groupBox1.Controls.Add(ticketNmbTBox);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(voidButton);
            groupBox1.Location = new Point(6, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(158, 249);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Anulación";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(29, 90);
            label7.Name = "label7";
            label7.Size = new Size(98, 15);
            label7.TabIndex = 29;
            label7.Text = "Código de tarjeta";
            // 
            // codCardVoidTBox
            // 
            codCardVoidTBox.Location = new Point(49, 108);
            codCardVoidTBox.MaxLength = 3;
            codCardVoidTBox.Name = "codCardVoidTBox";
            codCardVoidTBox.Size = new Size(57, 23);
            codCardVoidTBox.TabIndex = 28;
            codCardVoidTBox.Text = "0VI";
            codCardVoidTBox.TextAlign = HorizontalAlignment.Center;
            // 
            // ticketNmbTBox
            // 
            ticketNmbTBox.Location = new Point(41, 49);
            ticketNmbTBox.Maximum = new decimal(new int[] { 9999, 0, 0, 0 });
            ticketNmbTBox.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            ticketNmbTBox.Name = "ticketNmbTBox";
            ticketNmbTBox.Size = new Size(86, 23);
            ticketNmbTBox.TabIndex = 27;
            ticketNmbTBox.TextAlign = HorizontalAlignment.Center;
            ticketNmbTBox.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(49, 31);
            label10.Name = "label10";
            label10.Size = new Size(69, 15);
            label10.TabIndex = 26;
            label10.Text = "Cupón Org.";
            // 
            // voidButton
            // 
            voidButton.Location = new Point(29, 197);
            voidButton.Name = "voidButton";
            voidButton.Size = new Size(96, 30);
            voidButton.TabIndex = 23;
            voidButton.Text = "Anular";
            voidButton.UseVisualStyleBackColor = true;
            voidButton.Click += voidButton_Click;
            // 
            // consultasTab
            // 
            consultasTab.Controls.Add(getVersionButton);
            consultasTab.Controls.Add(getLastTrxButton);
            consultasTab.Controls.Add(getPlansButton);
            consultasTab.Controls.Add(lastBatchButton);
            consultasTab.Controls.Add(cardsButton);
            consultasTab.Enabled = false;
            consultasTab.Location = new Point(4, 24);
            consultasTab.Name = "consultasTab";
            consultasTab.Padding = new Padding(3);
            consultasTab.Size = new Size(421, 328);
            consultasTab.TabIndex = 1;
            consultasTab.Text = "Consultas";
            consultasTab.UseVisualStyleBackColor = true;
            // 
            // getLastTrxButton
            // 
            getLastTrxButton.Location = new Point(26, 86);
            getLastTrxButton.Name = "getLastTrxButton";
            getLastTrxButton.Size = new Size(170, 30);
            getLastTrxButton.TabIndex = 3;
            getLastTrxButton.Text = "Consulta última transacción";
            getLastTrxButton.UseVisualStyleBackColor = true;
            getLastTrxButton.Click += getLastTrxButton_Click;
            // 
            // getPlansButton
            // 
            getPlansButton.Location = new Point(224, 175);
            getPlansButton.Name = "getPlansButton";
            getPlansButton.Size = new Size(170, 30);
            getPlansButton.TabIndex = 2;
            getPlansButton.Text = "Consulta Planes";
            getPlansButton.UseVisualStyleBackColor = true;
            getPlansButton.Click += getPlansButton_Click;
            // 
            // lastBatchButton
            // 
            lastBatchButton.Location = new Point(224, 86);
            lastBatchButton.Name = "lastBatchButton";
            lastBatchButton.Size = new Size(170, 30);
            lastBatchButton.TabIndex = 1;
            lastBatchButton.Text = "Consulta de último cierre";
            lastBatchButton.UseVisualStyleBackColor = true;
            lastBatchButton.Click += lastBatchButton_Click;
            // 
            // cardsButton
            // 
            cardsButton.Location = new Point(26, 175);
            cardsButton.Name = "cardsButton";
            cardsButton.Size = new Size(170, 30);
            cardsButton.TabIndex = 0;
            cardsButton.Text = "Consulta Tarjetas";
            cardsButton.UseVisualStyleBackColor = true;
            cardsButton.Click += cardsButton_Click;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // outputTextBox
            // 
            outputTextBox.Location = new Point(445, 68);
            outputTextBox.Name = "outputTextBox";
            outputTextBox.ReadOnly = true;
            outputTextBox.Size = new Size(274, 319);
            outputTextBox.TabIndex = 8;
            outputTextBox.Text = "";
            // 
            // getVersionButton
            // 
            getVersionButton.Location = new Point(118, 252);
            getVersionButton.Name = "getVersionButton";
            getVersionButton.Size = new Size(170, 30);
            getVersionButton.TabIndex = 4;
            getVersionButton.Text = "Consulta Version Protocolo";
            getVersionButton.UseVisualStyleBackColor = true;
            getVersionButton.Click += getVersionButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(727, 395);
            Controls.Add(outputTextBox);
            Controls.Add(comandsGroupBox);
            Controls.Add(updateComPorts);
            Controls.Add(comTestButton);
            Controls.Add(ComButton);
            Controls.Add(portSelectBox);
            Name = "Form1";
            Text = "Demo VpiPc";
            comandsGroupBox.ResumeLayout(false);
            commandsTabs.ResumeLayout(false);
            ventaTab.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)instQrTBox).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            Extracash.ResumeLayout(false);
            Extracash.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)InstPurchaseTBox).EndInit();
            anvTab.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ticketNumberTBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)instalDevTBox).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ticketNmbTBox).EndInit();
            consultasTab.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private ComboBox portSelectBox;
        private Button ComButton;
        private Button comTestButton;
        private Button updateComPorts;
        private GroupBox comandsGroupBox;
        private ContextMenuStrip contextMenuStrip1;
        private RichTextBox outputTextBox;
        private TabControl commandsTabs;
        private TabPage ventaTab;
        private GroupBox Extracash;
        private TextBox extracashTBox;
        private Button extracashButton;
        private Label label5;
        private Label label4;
        private TextBox planPurchaseTBox;
        private TextBox cardCodPurchaseTBox;
        private TextBox amountPurchaseTBox;
        private Label label3;
        private NumericUpDown InstPurchaseTBox;
        private Label label2;
        private Label label1;
        private Button purchaseButton;
        private TabPage anvTab;
        private TabPage consultasTab;
        private Button cardsButton;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private Label label7;
        private TextBox codCardVoidTBox;
        private NumericUpDown ticketNmbTBox;
        private Label label10;
        private Button voidButton;
        private Label label11;
        private TextBox planDevTBox;
        private TextBox cardDevTBox;
        private TextBox amountDevTBox;
        private Label label12;
        private NumericUpDown instalDevTBox;
        private Label label13;
        private Label label14;
        private Button devButton;
        private NumericUpDown ticketNumberTBox;
        private Label label15;
        private Label label16;
        private TextBox textBox1;
        private GroupBox groupBox4;
        private Label label6;
        private TextBox planQrTBox;
        private TextBox amountQrTBox;
        private NumericUpDown instQrTBox;
        private Label label8;
        private Label label9;
        private Button qrButton;
        private GroupBox groupBox3;
        private GroupBox groupBox5;
        private Button batchButton;
        private Button lastBatchButton;
        private Button getLastTrxButton;
        private Button getPlansButton;
        private Button getVersionButton;
    }
}
