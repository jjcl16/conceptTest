﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoIntegracionVpiPc
{
    public class checkPorts
    {
        public static Array Ports() 
        {
            return SerialPort.GetPortNames();
        }
        
}
}
