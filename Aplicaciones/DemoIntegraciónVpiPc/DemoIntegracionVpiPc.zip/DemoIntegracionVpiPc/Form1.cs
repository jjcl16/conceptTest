using Microsoft.VisualBasic;
using Microsoft.Win32;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using System.Windows.Forms.Design;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace DemoIntegracionVpiPc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Apertura y cierre de puertos
        private void ComButton_Click(object sender, EventArgs e)
        {
            // Debug.WriteLine(portSelectBox.Text);

            if (ComButton.Text == "Abrir")
            {
                int selectedIndex = portSelectBox.SelectedIndex;
                object selectedItem = portSelectBox.SelectedItem;
                // Debug.WriteLine(selectedItem.ToString());
                comParams_t comParams = new comParams_t
                {
                    com = (selectedItem == null) ? " " : selectedItem.ToString(),
                    baudRate = 9600,    // Velocidad de transmici�n: 19200
                    byteSize = 8,       // Largo del byte: 8
                    parity = 'N',       // Paridad: 'N'
                    stopBits = 1
                };

                int resp = vpiPcConnector.vpiOpenPort(ref comParams);
                //printOutputText("resp: " + resp);
                if (resp == responseValues.VPI_OK)
                {
                    ComButton.Text = "Cerrar";
                    portSelectBox.Enabled = false;
                    comTestButton.Enabled = true;
                    ventaTab.Enabled = true;
                    anvTab.Enabled = true;
                    consultasTab.Enabled = true;
                    printOutputText("Puerto Abierto");

                }
            }
            else
            {
                int resp = vpiPcConnector.vpiClosePort();
                if (resp == responseValues.VPI_OK)
                {
                    ComButton.Text = "Abrir";
                    portSelectBox.Enabled = true;
                    comTestButton.Enabled = false;
                    ventaTab.Enabled = false;
                    anvTab.Enabled = false;
                    consultasTab.Enabled = false;
                    printOutputText("Puerto Cerrado");
                }
            }
        }

        // Test de comunicaci�n
        private void comTestButton_Click(object sender, EventArgs e)
        {
            printOutputText("Chequeando Comunicaci�n Iniciado \n");
            int resp = vpiPcConnector.vpiTestConnection();
            if (resp == responseValues.VPI_OK)
            {
                printOutputText("PoS conectado", false);
            }
            else
            {

                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }

        }

        // Actualizar coms
        private void updateComPorts_Click(object sender, EventArgs e)
        {
            portSelectBox.Items.Clear();
            portSelectBox.Items.AddRange((object[])checkPorts.Ports());
        }

        // Venta
        private void purchaseButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando de venta iniciado \n");
            vpiPurchaseIn_t purchaseIn_T = new vpiPurchaseIn_t
            {
                amount = amountPurchaseTBox.Text,               // Monto 5250,00 x100
                receiptNumber = "2536894",                      // N�mero de factura  
                instalmentCount = InstPurchaseTBox.Text,        // Cant. de cuotas  
                issuerCode = cardCodPurchaseTBox.Text,          // C�digo de tarjeta  
                planCode = planPurchaseTBox.Text,               // C�digo de plan  
                tip = "0",                                      // Propina x100
                merchantCode = "03659307",                      // C�digo de comercio a utilizar
                merchantName = "Payway SAU",                    // Raz�n social del comercio
                cuit = "30-59685269-2",                         // CUIT del comercio
                linemode = '1',                                 // online
            };


            vpiTrxMarkOut1_t trxMarkOut1_T = new vpiTrxMarkOut1_t
            {
                hostRespCode = new string(' ', 2),     // C�digo de respuesta del host   
                hostMessage = new string(' ', 32),     // Mensaje de respuesta del host   
                authCode = new string(' ', 6),         // N�mero de autorizaci�n   
                ticketNumber = new string(' ', 7),     // N�mero de cup�n   
                batchNumber = new string(' ', 3),     // N�mero de lote   
                customerName = new string(' ', 26),     // Nombre del tarjeta-habiente   
                panLast4 = new string(' ', 4),        // Ultimo 4 digitos de la tarjeta   
                panFirst6 = new string(' ', 6),        // Primeros 6 digitos de la tarjeta	
                date = new string(' ', 10),             // Fecha de la transacci�n (DD/MM/AAAA)  
                time = new string(' ', 8),             // Hora de la transaccion (HH:MM:SS)
                terminalID = new string(' ', 8),       // N�mero de Terminal
                issuerCode = new string(' ', 3),       // C�digo de tarjeta
                merchantCode = new string(' ', 15),     // C�digo de comercio
                aipEmv = new string(' ', 15),           // Aip para EMV
                appEmv = new string(' ', 15),          // App para EMV
                promoMsg = new string(' ', 200),        // Mensaje promocional
            };


            int resp = vpiPcConnector.vpiPurchaseMark(ref purchaseIn_T, ref trxMarkOut1_T, 6000);
            if (resp == responseValues.VPI_OK)
            {
                printOutputText(
                    "Comando Completado: Venta \n" +
                    "Respuesta del host: " + hostResponseCodeToMessage(trxMarkOut1_T.hostRespCode) + "\n" +
                    "C�digo del Autorizador: " + trxMarkOut1_T.hostRespCode + "\n" +
                    "Mensaje del Autorizador: " + trxMarkOut1_T.hostMessage + "\n" +
                    "N�mero de autorizaci�n: " + trxMarkOut1_T.authCode + "\n" +
                    "N�mero de cup�n: " + trxMarkOut1_T.ticketNumber + "\n" +
                    "N�mero de Lote: " + trxMarkOut1_T.batchNumber + "\n" +
                    "Nombre en la tarjeta: " + trxMarkOut1_T.customerName + "\n" +
                    "�ltimos 4 de la tarjeta: " + trxMarkOut1_T.panLast4 + "\n" +
                    "Bin de la Tarjeta: " + trxMarkOut1_T.panFirst6 + "\n" +
                    "Fecha: " + trxMarkOut1_T.date + "\n" +
                    "Hora: " + trxMarkOut1_T.time + "\n" +
                    "terminal ID:" + trxMarkOut1_T.terminalID + "\n" +
                    "C�digo de tarjeta:" + trxMarkOut1_T.issuerCode + "\n" +
                    "C�digo de comercio:" + trxMarkOut1_T.merchantCode + "\n" +
                    "aipEmv:" + trxMarkOut1_T.aipEmv + "\n" +
                    "appEmv:" + trxMarkOut1_T.appEmv + "\n" +
                    "Promocional de la marca:" + trxMarkOut1_T.promoMsg + "\n"
                    , false);

            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }
        }

        // Venta + Extracci�n
        private void extracashButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando Extracash iniciado \n");
            vpiPurchaseIn_t purchaseIn_T = new vpiPurchaseIn_t
            {
                amount = amountPurchaseTBox.Text,               // Monto 5250,00 x100
                receiptNumber = "2536894",                      // N�mero de factura  
                instalmentCount = InstPurchaseTBox.Text,        // Cant. de cuotas  
                issuerCode = cardCodPurchaseTBox.Text,          // C�digo de tarjeta  
                planCode = planPurchaseTBox.Text,               // C�digo de plan  
                tip = extracashTBox.Text,                       // Extracash x100
                merchantCode = "03659307",                      // C�digo de comercio a utilizar
                merchantName = "Payway SAU",                    // Raz�n social del comercio
                cuit = "30-59685269-2",                         // CUIT del comercio
                linemode = '1',                                 // online
            };


            vpiTrxMarkOut1_t trxMarkOut1_T = new vpiTrxMarkOut1_t
            {
                hostRespCode = new string(' ', 2),     // C�digo de respuesta del host   
                hostMessage = new string(' ', 32),     // Mensaje de respuesta del host   
                authCode = new string(' ', 6),         // N�mero de autorizaci�n   
                ticketNumber = new string(' ', 7),     // N�mero de cup�n   
                batchNumber = new string(' ', 3),     // N�mero de lote   
                customerName = new string(' ', 26),     // Nombre del tarjeta-habiente   
                panLast4 = new string(' ', 4),        // Ultimo 4 digitos de la tarjeta   
                panFirst6 = new string(' ', 6),        // Primeros 6 digitos de la tarjeta	
                date = new string(' ', 10),             // Fecha de la transacci�n (DD/MM/AAAA)  
                time = new string(' ', 8),             // Hora de la transaccion (HH:MM:SS)
                terminalID = new string(' ', 8),       // N�mero de Terminal
                issuerCode = new string(' ', 3),       // C�digo de tarjeta
                merchantCode = new string(' ', 15),     // C�digo de comercio
                aipEmv = new string(' ', 15),           // Aip para EMV
                appEmv = new string(' ', 15),          // App para EMV
                promoMsg = new string(' ', 200),        // Mensaje promocional
            };


            int resp = vpiPcConnector.vpiPurchaseExtraCashMark(ref purchaseIn_T, ref trxMarkOut1_T, 6000);
            if (resp == responseValues.VPI_OK)
            {
                printOutputText(
                    "Comando Completado: Venta + Extracci�n \n" +
                    "Respuesta del host: " + hostResponseCodeToMessage(trxMarkOut1_T.hostRespCode) + "\n" +
                    "C�digo del Autorizador: " + trxMarkOut1_T.hostRespCode + "\n" +
                    "Mensaje del Autorizador: " + trxMarkOut1_T.hostMessage + "\n" +
                    "N�mero de autorizaci�n: " + trxMarkOut1_T.authCode + "\n" +
                    "N�mero de cup�n: " + trxMarkOut1_T.ticketNumber + "\n" +
                    "N�mero de Lote: " + trxMarkOut1_T.batchNumber + "\n" +
                    "Nombre en la tarjeta: " + trxMarkOut1_T.customerName + "\n" +
                    "�ltimos 4 de la tarjeta: " + trxMarkOut1_T.panLast4 + "\n" +
                    "Bin de la Tarjeta: " + trxMarkOut1_T.panFirst6 + "\n" +
                    "Fecha: " + trxMarkOut1_T.date + "\n" +
                    "Hora: " + trxMarkOut1_T.time + "\n" +
                    "Terminal ID:" + trxMarkOut1_T.terminalID + "\n" +
                    "C�digo de tarjeta:" + trxMarkOut1_T.issuerCode + "\n" +
                    "C�digo de comercio:" + trxMarkOut1_T.merchantCode + "\n" +
                    "AipEmv:" + trxMarkOut1_T.aipEmv + "\n" +
                    "AppEmv:" + trxMarkOut1_T.appEmv + "\n" +
                    "Promocional de la marca:" + trxMarkOut1_T.promoMsg + "\n"
                    , false);

            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }
        }

        // Venta QR
        private void qrButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando de venta iniciado \n");
            vpiQrzIn_t vpiQrzIn_T = new vpiQrzIn_t
            {
                ammount = amountQrTBox.Text,    // Monto 5250,00 x100 
                cantCoutas = instQrTBox.Text,   // Cant. de cuotas 
                planCod = planQrTBox.Text,      // C�digo de plan
            };


            vpiQrzOut_t vpiQrzOut_T = new vpiQrzOut_t
            {
                respcode = new string(' ', 2),      // C�digo de respuesta del host   
                respMsg = new string(' ', 32),      // Mensaje de respuesta del host   
                authCode = new string(' ', 6),      // N�mero de autorizaci�n   
                cuponNmb = new string(' ', 7),      // N�mero de cup�n   
                loteNmb = new string(' ', 3),       // N�mero de lote   
                lastFour = new string(' ', 4),      // Ultimo 4 digitos de la tarjeta   
                firstSix = new string(' ', 6),      // Primeros 6 digitos de la tarjeta	
                trxDate = new string(' ', 10),      // Fecha de la transacci�n (DD/MM/AAAA)  
                trxHr = new string(' ', 8),         // Hora de la transaccion (HH:MM:SS)
                terminalID = new string(' ', 8),    // N�mero de Terminal
                cardCod = new string(' ', 3),       // C�digo de tarjeta
                impTotal = new string(' ', 12),     // Monto total
                impCobrado = new string(' ', 12),   // Monto cobrado
            };


            int resp = vpiPcConnector.vpiGetQRZ(ref vpiQrzIn_T, ref vpiQrzOut_T, 6000);
            if (resp == responseValues.VPI_OK)
            {
                printOutputText(
                    "Comando Completado: Venta QR \n" +
                    "Respuesta del host: " + hostResponseCodeToMessage(vpiQrzOut_T.respcode) + "\n" +
                    "C�digo del Autorizador: " + vpiQrzOut_T.respcode + "\n" +
                    "Mensaje del Autorizador: " + vpiQrzOut_T.respMsg + "\n" +
                    "N�mero de autorizaci�n: " + vpiQrzOut_T.authCode + "\n" +
                    "N�mero de cup�n: " + vpiQrzOut_T.cuponNmb + "\n" +
                    "N�mero de Lote: " + vpiQrzOut_T.loteNmb + "\n" +
                    "�ltimos 4 de la tarjeta: " + vpiQrzOut_T.lastFour + "\n" +
                    "Bin de la Tarjeta: " + vpiQrzOut_T.firstSix + "\n" +
                    "Fecha: " + vpiQrzOut_T.trxDate + "\n" +
                    "Hora: " + vpiQrzOut_T.trxHr + "\n" +
                    "Terminal ID: " + vpiQrzOut_T.terminalID + "\n" +
                    "C�digo de tarjeta: " + vpiQrzOut_T.cardCod + "\n" +
                    "Monto total: " + vpiQrzOut_T.impTotal + "\n" +
                    "Monto cobrado: " + vpiQrzOut_T.impCobrado + "\n"
                    , false);

            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }
        }

        // Anulaci�n
        private void voidButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando de anulaci�n iniciado \n");
            vpiVoidIn_t vpiVoidIn_T = new vpiVoidIn_t
            {
                originalTicket = ticketNmbTBox.Text,    // Numero de cupon original                 
                issuerCode = codCardVoidTBox.Text,      // Codigo de tarjeta                
                merchantName = "Payway SAU",            // Raz�n social del comercio
                cuit = "30-59685269-2",                 // CUIT del comercio
            };


            vpiTrxOut_t vpiTrxOut_T = new vpiTrxOut_t
            {
                hostRespCode = new string(' ', 2),     // C�digo de respuesta del host   
                hostMessage = new string(' ', 32),     // Mensaje de respuesta del host   
                authCode = new string(' ', 6),         // N�mero de autorizaci�n   
                ticketNumber = new string(' ', 7),     // N�mero de cup�n   
                batchNumber = new string(' ', 3),     // N�mero de lote   
                customerName = new string(' ', 26),     // Nombre del tarjeta-habiente   
                panLast4 = new string(' ', 4),        // Ultimo 4 digitos de la tarjeta   
                panFirst6 = new string(' ', 6),        // Primeros 6 digitos de la tarjeta	
                date = new string(' ', 10),             // Fecha de la transacci�n (DD/MM/AAAA)  
                time = new string(' ', 8),             // Hora de la transaccion (HH:MM:SS)
                terminalID = new string(' ', 8),       // N�mero de Terminal
            };


            int resp = vpiPcConnector.vpiVoid(ref vpiVoidIn_T, ref vpiTrxOut_T, 6000);
            if (resp == responseValues.VPI_OK)
            {
                printOutputText(
                    "Comando Completado: Anulaci�n \n" +
                    "Respuesta del host: " + hostResponseCodeToMessage(vpiTrxOut_T.hostRespCode) + "\n" +
                    "C�digo del Autorizador: " + vpiTrxOut_T.hostRespCode + "\n" +
                    "Mensaje del Autorizador: " + vpiTrxOut_T.hostMessage + "\n" +
                    "N�mero de autorizaci�n: " + vpiTrxOut_T.authCode + "\n" +
                    "N�mero de cup�n: " + vpiTrxOut_T.ticketNumber + "\n" +
                    "N�mero de Lote: " + vpiTrxOut_T.batchNumber + "\n" +
                    "Nombre en la tarjeta: " + vpiTrxOut_T.customerName + "\n" +
                    "�ltimos 4 de la tarjeta: " + vpiTrxOut_T.panLast4 + "\n" +
                    "Bin de la Tarjeta: " + vpiTrxOut_T.panFirst6 + "\n" +
                    "Fecha: " + vpiTrxOut_T.date + "\n" +
                    "Hora: " + vpiTrxOut_T.time + "\n" +
                    "terminal ID:" + vpiTrxOut_T.terminalID + "\n"
                    , false);

            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }
        }

        // Devoluci�n
        private void devButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando de devoluci�n iniciado \n");
            vpiRefundIn_t vpiRefundIn_T = new vpiRefundIn_t
            {
                amount = amountDevTBox.Text,               // Monto 5250,00 x100 
                instalmentCount = instalDevTBox.Text,        // Cant. de cuotas  
                issuerCode = cardDevTBox.Text,          // C�digo de tarjeta  
                planCode = planDevTBox.Text,               // C�digo de plan
                originalTicket = ticketNumberTBox.Text,   // Nro. ticket de la trx. original
                originalDate = "",                          // Fecha de la trx original
                receiptNumber = "2536894",                      // N�mero de factura 
                merchantCode = "03659307",                      // C�digo de comercio a utilizar
                merchantName = "Payway SAU",                    // Raz�n social del comercio
                cuit = "30-59685269-2",                         // CUIT del comercio
                linemode = '1',                                 // online
            };


            vpiTrxOut_t vpiTrxOut_T = new vpiTrxOut_t
            {
                hostRespCode = new string(' ', 2),     // C�digo de respuesta del host   
                hostMessage = new string(' ', 32),     // Mensaje de respuesta del host   
                authCode = new string(' ', 6),         // N�mero de autorizaci�n   
                ticketNumber = new string(' ', 7),     // N�mero de cup�n   
                batchNumber = new string(' ', 3),     // N�mero de lote   
                customerName = new string(' ', 26),     // Nombre del tarjeta-habiente   
                panLast4 = new string(' ', 4),        // Ultimo 4 digitos de la tarjeta   
                panFirst6 = new string(' ', 6),        // Primeros 6 digitos de la tarjeta	
                date = new string(' ', 10),             // Fecha de la transacci�n (DD/MM/AAAA)  
                time = new string(' ', 8),             // Hora de la transaccion (HH:MM:SS)
                terminalID = new string(' ', 8),       // N�mero de Terminal
            };


            int resp = vpiPcConnector.vpiRefund(ref vpiRefundIn_T, ref vpiTrxOut_T, 6000);
            if (resp == responseValues.VPI_OK)
            {
                printOutputText(
                    "Comando Completado: Devoluci�n \n" +
                    "Respuesta del host: " + hostResponseCodeToMessage(vpiTrxOut_T.hostRespCode) + "\n" +
                    "C�digo del Autorizador: " + vpiTrxOut_T.hostRespCode + "\n" +
                    "Mensaje del Autorizador: " + vpiTrxOut_T.hostMessage + "\n" +
                    "N�mero de autorizaci�n: " + vpiTrxOut_T.authCode + "\n" +
                    "N�mero de cup�n: " + vpiTrxOut_T.ticketNumber + "\n" +
                    "N�mero de Lote: " + vpiTrxOut_T.batchNumber + "\n" +
                    "Nombre en la tarjeta: " + vpiTrxOut_T.customerName + "\n" +
                    "�ltimos 4 de la tarjeta: " + vpiTrxOut_T.panLast4 + "\n" +
                    "Bin de la Tarjeta: " + vpiTrxOut_T.panFirst6 + "\n" +
                    "Fecha: " + vpiTrxOut_T.date + "\n" +
                    "Hora: " + vpiTrxOut_T.time + "\n" +
                    "terminal ID:" + vpiTrxOut_T.terminalID + "\n"
                    , false);

            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }
        }

        // Cierre de lote
        private void batchButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando cierre de lote iniciado \n");
            int resp = 1;


            vpiBatchCloseOut_t vpiBatchCloseOut_T = new vpiBatchCloseOut_t
            {
                hostRespCode = new string(' ', 2),      // C�digo de respuesta del host  
                date = new string(' ', 10),             // Fecha   
                time = new string(' ', 8),              // Hora
                terminalID = new string(' ', 8)         // Terminal id
            };

            //printOutputText("Comando Completado: Cierre de Lote \n", false);

            resp = vpiPcConnector.vpiBatchClose(ref vpiBatchCloseOut_T, 6000);
            if (resp == responseValues.VPI_OK)
            {
                printOutputText(
                "Comando Completado: Cierre de Lote \n" +
                "Respuesta del host: " + hostResponseCodeToMessage(vpiBatchCloseOut_T.hostRespCode) + "\n" +
                "Codigo de respuesta del host: " + vpiBatchCloseOut_T.hostRespCode + "\n" +
                "Fecha: " + vpiBatchCloseOut_T.date + "\n" +
                "Hora: " + vpiBatchCloseOut_T.time + "\n" +
                "Terminal ID: " + vpiBatchCloseOut_T.terminalID + "\n"
                , false);
            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);

            }


        }

        // Consulta de ultima transacci�n
        private void getLastTrxButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando consulta de �ltima transacci�n iniciado \n");
            int resp = 1;
            uint trxCode = 0;

            vpiTrxOut_t vpiTrxOut_T = new vpiTrxOut_t
            {
                hostRespCode = new string(' ', 2),     // C�digo de respuesta del host   
                hostMessage = new string(' ', 32),     // Mensaje de respuesta del host   
                authCode = new string(' ', 6),         // N�mero de autorizaci�n   
                ticketNumber = new string(' ', 7),     // N�mero de cup�n   
                batchNumber = new string(' ', 3),     // N�mero de lote   
                customerName = new string(' ', 26),     // Nombre del tarjeta-habiente   
                panLast4 = new string(' ', 4),        // Ultimo 4 digitos de la tarjeta   
                panFirst6 = new string(' ', 6),        // Primeros 6 digitos de la tarjeta	
                date = new string(' ', 10),             // Fecha de la transacci�n (DD/MM/AAAA)  
                time = new string(' ', 8),             // Hora de la transaccion (HH:MM:SS)
                terminalID = new string(' ', 8),       // N�mero de Terminal
            };


            resp = vpiPcConnector.vpiGetLastTrxData(ref trxCode, ref vpiTrxOut_T);
            if (resp == responseValues.VPI_OK)
            {
                string tipoTransaccionToString =
                    (trxCode == 1) ? "Venta" :
                    (trxCode == 2) ? "Anulaci�n" : "Devoluci�n";

                printOutputText(
                    "Comando Completado: Devoluci�n \n" +
                    "Tipo de transacci�n:" + tipoTransaccionToString + "\n" +
                    "C�digo de tipo de transacci�n:" + trxCode.ToString() + "\n" +
                    "Respuesta del host: " + hostResponseCodeToMessage(vpiTrxOut_T.hostRespCode) + "\n" +
                    "C�digo del Autorizador: " + vpiTrxOut_T.hostRespCode + "\n" +
                    "Mensaje del Autorizador: " + vpiTrxOut_T.hostMessage + "\n" +
                    "N�mero de autorizaci�n: " + vpiTrxOut_T.authCode + "\n" +
                    "N�mero de cup�n: " + vpiTrxOut_T.ticketNumber + "\n" +
                    "N�mero de Lote: " + vpiTrxOut_T.batchNumber + "\n" +
                    "Nombre en la tarjeta: " + vpiTrxOut_T.customerName + "\n" +
                    "�ltimos 4 de la tarjeta: " + vpiTrxOut_T.panLast4 + "\n" +
                    "Bin de la Tarjeta: " + vpiTrxOut_T.panFirst6 + "\n" +
                    "Fecha: " + vpiTrxOut_T.date + "\n" +
                    "Hora: " + vpiTrxOut_T.time + "\n" +
                    "terminal ID:" + vpiTrxOut_T.terminalID + "\n"
                    , false);

            }
            else
            {
                printOutputText(
                    vpiErrorMessage(
                        checkPortOnVpiErrors(resp)
                        )
                    , false);
            }
        }

        // Consulta de ultimo cierre
        private void lastBatchButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando consulta de �ltimo Lote cerrado iniciado\n");
            int resp = 1;


            vpiBatchCloseDataOut_t vpiBatchCloseDataOut_T = new vpiBatchCloseDataOut_t
            {
                index = 0,                              // �ndice del registro.	 
                acquirerCode = new string(' ', 3),      // C�digo de procesador.   
                batchNumber = new string(' ', 3),       // N�mero de lote.   
                issuerCode = new string(' ', 3),        // C�digo de tarjeta   
                purchaseCount = new string(' ', 4),     // Cantidad de ventas.   
                purchaseAmount = new string(' ', 12),   // Monto total de ventas.   
                voidCount = new string(' ', 4),         // Cantidad anulaciones de venta.   
                voidAmount = new string(' ', 12),       // Monto total de anulaciones.   
                refundCount = new string(' ', 4),       // Cantidad de devoluciones venta.   
                refundAmount = new string(' ', 12),     // Monto total de devoluciones.   
                refvoidCount = new string(' ', 4),      // Cantidad anulaciones devoluci�n.   
                refvoidAmount = new string(' ', 12),    // Monto total anul. devoluci�n.
                date = new string(' ', 10),             // Fecha ("DD/MM/AAAA")  
                time = new string(' ', 8),              // Hora ("HH:MM:SS")
                terminalID = new string(' ', 8)         // Terminal id

            };

            uint index = 0;
            //printOutputText("Comando Completado: Consulta tarjetas \n");
            while (resp == responseValues.VPI_MORE_REC)
            {
                resp = vpiPcConnector.vpiGetBatchCloseData(index, ref vpiBatchCloseDataOut_T);
                // inicializa output
                if (resp == responseValues.VPI_MORE_REC || resp == responseValues.VPI_OK)
                {
                    printOutputText(
                    "Indice: " + vpiBatchCloseDataOut_T.index.ToString() + "\n" +
                    "N�mero de lote: " + vpiBatchCloseDataOut_T.batchNumber + "\n" +
                    "C�digo de procesador: " + vpiBatchCloseDataOut_T.acquirerCode + "\n" +
                    "C�digo de tarjeta: " + vpiBatchCloseDataOut_T.issuerCode + "\n" +
                    "Cant. Ventas: " + vpiBatchCloseDataOut_T.purchaseCount + "\n" +
                    "Total de ventas: " + vpiBatchCloseDataOut_T.purchaseAmount + "\n" +
                    "Cant. Anulaciones: " + vpiBatchCloseDataOut_T.voidCount + "\n" +
                    "Total de anulaciones: " + vpiBatchCloseDataOut_T.voidAmount + "\n" +
                    "Cant. Devoluciones: " + vpiBatchCloseDataOut_T.refundCount + "\n" +
                    "Total de devoluciones: " + vpiBatchCloseDataOut_T.refundAmount + "\n" +
                    "Terminal ID: " + vpiBatchCloseDataOut_T.terminalID + "\n"
                    , false);
                    index++;
                }
                else
                {
                    printOutputText(
                        vpiErrorMessage(
                            checkPortOnVpiErrors(resp)
                            )
                        , false);
                }

            }
        }

        // Consulta tarjetas
        private void cardsButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando consulta de tarjetas iniciado \n");
            int resp = 1;


            vpiIssuerOut_t vpiIssuerOut_T = new vpiIssuerOut_t
            {
                index = 0,                              // �ndice del registro.	 
                acquirerCode = new string(' ', 3),      // C�digo de procesador.   
                issuerCode = new string(' ', 3),        // C�digo de tarjeta   
                issuerName = new string(' ', 16),       // Nombre de la tarjeta   
                maxInstCount = new string(' ', 2),      // Maxima cantidad de cuotas
                terminalID = new string(' ', 8)         // Terminal id
            };

            uint index = 0;
            //printOutputText("Comando Completado: Consulta tarjetas \n");
            while (resp == responseValues.VPI_MORE_REC)
            {
                resp = vpiPcConnector.vpiGetIssuer(index, ref vpiIssuerOut_T);
                // inicializa output
                if (resp == responseValues.VPI_MORE_REC || resp == responseValues.VPI_OK)
                {
                    printOutputText(
                    "Indice: " + vpiIssuerOut_T.index.ToString() + "\n" +
                    "C�digo de procesador: " + vpiIssuerOut_T.acquirerCode + "\n" +
                    "C�digo de tarjeta: " + vpiIssuerOut_T.issuerCode + "\n" +
                    "Nombre de la tarjeta: " + vpiIssuerOut_T.issuerName + "\n" +
                    "Cantida maxima de cuotas: " + vpiIssuerOut_T.maxInstCount + "\n" +
                    "Terminal ID: " + vpiIssuerOut_T.terminalID + "\n"
                    , false);
                    index++;
                }
                else
                {
                    printOutputText(
                        vpiErrorMessage(
                            checkPortOnVpiErrors(resp)
                            )
                        , false);
                }

            }
        }

        // Consulta de planes
        private void getPlansButton_Click(object sender, EventArgs e)
        {
            printOutputText("Comando consulta de planes iniciado \n");
            int resp = 1;


            vpiPlanOut_t vpiPlanOut_T = new vpiPlanOut_t
            {
                index = 0,                              // �ndice del registro.
                issuerCode = new string(' ', 3),        // C�digo de tarjeta   
                planCode = new string(' ', 2),          // C�digo de plan 
                planLabel = new string(' ', 14),        // Nombre del plan
                terminalID = new string(' ', 8)         // Terminal id
            };

            uint index = 0;
            //printOutputText("Comando Completado: Consulta tarjetas \n");
            while (resp == responseValues.VPI_MORE_REC)
            {
                resp = vpiPcConnector.vpiGetPlan(index, ref vpiPlanOut_T);
                // inicializa output
                if (resp == responseValues.VPI_MORE_REC || resp == responseValues.VPI_OK)
                {
                    printOutputText(
                    "Indice: " + vpiPlanOut_T.index.ToString() + "\n" +
                    "C�digo de tarjeta: " + vpiPlanOut_T.issuerCode + "\n" +
                    "C�digo del plan: " + vpiPlanOut_T.planCode + "\n" +
                    "Nombre del plan: " + vpiPlanOut_T.planLabel + "\n" +
                    "Terminal ID: " + vpiPlanOut_T.terminalID + "\n"
                    , false);
                    index++;
                }
                else
                {
                    printOutputText(
                        vpiErrorMessage(
                            checkPortOnVpiErrors(resp)
                            )
                        , false);
                }

            }
        }


        /****
         * 
         * Facilitadores y manejos de respuestas y errores
         
         */



        // Manejar errores VPI_FAIL y VPI_TIMEOUT_EXP -> para estos dos errores, es posible que el puerto se encuentre cerrado.
        private int checkPortOnVpiErrors(int vpiError)
        {
            int resp = vpiPcConnector.vpiTestConnection();
            if (resp != responseValues.VPI_OK)
            {
                comParams_t comParams = new comParams_t
                {
                    com = portSelectBox.Text,
                    baudRate = 9600,    // Velocidad de transmici�n: 19200
                    byteSize = 8,       // Largo del byte: 8
                    parity = 'N',       // Paridad: 'N'
                    stopBits = 1
                };

                Thread.Sleep(1000);
                resp = vpiPcConnector.vpiOpenPort(ref comParams);
                if (resp == responseValues.VPI_OK)
                {
                    return vpiError;
                }
                else
                {
                    ComButton.Text = "Abrir";
                    portSelectBox.Enabled = true;
                    comTestButton.Enabled = false;
                    ventaTab.Enabled = false;
                    anvTab.Enabled = false;
                    consultasTab.Enabled = false;
                    vpiPcConnector.vpiClosePort();
                    return 9999; // Error Auxiliar para determinar que el puerto no se pudo abrir nuevamente
                }
            }
            else
            {
                return vpiError;
            }

        }

        // Manejador de impresion de mensajes  -> impresion en el output Textbox
        private void printOutputText(string textToPrint, bool overwrite = true)
        {

            if (overwrite)
            {
                outputTextBox.Text = textToPrint;
                outputTextBox.Refresh();
            }
            else
            {
                outputTextBox.Text += textToPrint + "\n";
                outputTextBox.Refresh();
            }

        }

        // Manejador de mensajes de error VpiPc -> pasa de codError a Mensaje
        private string vpiErrorMessage(int vpiCode)
        {
            string msg = "Error no mapeado";

            switch (vpiCode)
            {

                case responseValues.VPI_FAIL:
                    msg = "El comando no pudo ser enviado.";
                    break;

                case responseValues.VPI_TIMEOUT_EXP:
                    msg = "Expir� el timeout.";
                    break;

                case responseValues.VPI_INVALID_ISSUER:
                    msg = "El c�digo de tarjeta no existe.";
                    break;

                case responseValues.VPI_INVALID_TICKET:
                    msg = "El n�mero de cup�n no existe.";
                    break;

                case responseValues.VPI_INVALID_PLAN:
                    msg = "El c�digo de plan no existe.";
                    break;

                case responseValues.VPI_INVALID_INDEX:
                    msg = "No existe el indice.";
                    break;

                case responseValues.VPI_EMPTY_BATCH:
                    msg = "El lote del POS se encuentra vac�o.";
                    break;

                case responseValues.VPI_TRX_CANCELED:
                    msg = "Transacci�n cancelada por el usuario.";
                    break;

                case responseValues.VPI_DIF_CARD:
                    msg = "La tarjeta deslizada por el usuario no coincide con la pedida.";
                    break;

                case responseValues.VPI_INVALID_CARD:
                    msg = "La tarjeta deslizada no es v�lida.";
                    break;

                case responseValues.VPI_EXPIRED_CARD:
                    msg = "La tarjeta deslizada est� vencida.";
                    break;

                case responseValues.VPI_INVALID_TRX:
                    msg = "La transacci�n original no existe.";
                    break;

                case responseValues.VPI_BATCH_EMPTY:
                    msg = "Lote Vac�o, debe tener operaciones en el lote para ser cerrado.";
                    break;

                case responseValues.VPI_ERR_COM:
                    msg = "El POS no pudo comunicarse con el host.";
                    break;

                case responseValues.VPI_ERR_PRINT:
                    msg = "El POS no pudo imprimir el ticket.";
                    break;

                case responseValues.VPI_INVALID_IN_CMD:
                    msg = "Nombre del comando inexistente.";
                    break;

                case responseValues.VPI_INVALID_IN_PARAM:
                    msg = "Formato de alg�n par�metro de entrada no es correcto.";
                    break;

                case responseValues.VPI_INVALID_OUT_CMD:
                    msg = "Respuesta invalida.";
                    break;

                case responseValues.VPI_GENERAL_FAIL:
                    msg = "Error general en la operaci�n.";
                    break;

                case 9999:  /// Error auxiliar 
                    msg = "Error en la comunicaci�n - Puerto Cerrado";
                    break;

            }

            return msg;
        }

        // Manejador de codigos de respuestas del host a mensaje interpretable -> pasa de cod a Mensaje
        private string hostResponseCodeToMessage(string hostResponseCode)
        {
            string message = "";
            switch (hostResponseCode)
            {
                case "00":                          // Operaci�n aprobada, emitir cup�n (cargo o ticket).
                case "11":                          // Operaci�n aprobada, emitir cup�n (cargo o ticket).
                case "85":                          // Operaci�n aprobada, emitir cup�n (cargo o ticket).
                    message = "APROBADO";
                    break;

                case "01":                          // Pedir autorizaci�n, solo para transacciones offline.
                case "02":                          // Pedir autorizaci�n, solo para transacciones offline.
                    message = "PEDIR AUTORIZACION";
                    break;

                case "03":                          // Comercio invalido, c�digo de comercio mal cargado
                    message = "COMERCIO INVALIDO";
                    break;

                case "04":                          // Denegada, capturar tarjeta.
                    message = "CAPTURAR TARJETA";
                    break;

                case "05":                          // Denegada.
                    message = "DENEGADA";
                    break;

                case "07":                          // Denegada, llamar al centro de autorizaciones.
                    message = "RETENGA Y LLAME";
                    break;

                case "08":                          // Aprobar y pedir identificaci�n
                    message = "APROBAR, PEDIR IDENT.";
                    break;

                case "12":                          // Verificar el sistema, transacci�n no reconocida en el sistema.
                    message = "TRANSAC. INVALIDA";
                    break;

                case "13":                          // Verificar el sistema, error en el formato del campo importe.
                    message = "MONTO INVALIDO";
                    break;

                case "14":                          // Denegada, tarjeta no corresponde.
                    message = "TARJETA INVALIDA";
                    break;

                case "19":                          // Reinicie operaci�n
                    message = "REINICIE OPERACI�N";
                    break;

                case "25":                          // Denegada, registro no encontrado en el archivo de transacciones
                    message = "NO EXISTE ORIGINAL";
                    break;

                case "30":                          // Verificar el sistema, error en el formato del mensaje.
                    message = "ERROR EN FORMATO";
                    break;

                case "38":                          // Denegada, excede cantidad de reintentos de PIN permitidos.
                    message = "EXCEDE ING.DE PIN";
                    break;

                case "42":                          // Denegada, retener tarjeta.
                    message = "RETENER TARJETA";
                    break;

                case "45":                          // Denegada, tarjeta inhibida para operar en cuotas.
                    message = "NO OPERA EN CUOTAS";
                    break;

                case "46":                          // Denegada, tarjeta no est� vigente a�n.
                    message = "ARJETA NO VIGENTE";
                    break;

                case "47":                          // Denegada, tarjeta no est� vigente a�n.
                    message = "PIN REQUERIDO";
                    break;

                case "48":                          // Denegada, excede cantidad m�xima de cuotas permitida.
                    message = "EXCEDE MAX. CUOTAS";
                    break;

                case "49":                          // Verificar el sistema, error en formato de fecha de expiraci�n(vto)
                    message = "ERROR FECHA VENCIMIENTO";
                    break;

                case "50":                          // Denegada, supera el limite permitido.
                    message = "ENTREGA SUPERA LIMITE";
                    break;

                case "51":                          // Denegada, no posee fondos suficientes
                    message = "FONDOS INSUFICIENTES";
                    break;

                case "53":                          // Denegada, no existe cuentas asociadas
                    message = "CUENTA INEXISTENTE";
                    break;

                case "54":                          // Denegada, Tarjeta vencida
                    message = "TARJETA VENCIDA";
                    break;

                case "55":                          // Denegada, Pin incorrecto.
                    message = "PIN INCORRECTO";
                    break;

                case "56":                          // Denegada, emisor no habilitado en el sistema
                    message = "TARJETA NO HABILITADA";
                    break;

                case "57":                          // Verificar el sistema, transacci�n no permitida a dicha tarjeta
                    message = "TRANSACCI�N NO PERMITIDA";
                    break;

                case "58":                          // Verificar el sistema, transacci�n no permitida a dicha terminal
                    message = "SERVICIO INVALIDO";
                    break;

                case "61":                          // Denegada, excede l�mite remanente de la tarjeta.
                    message = "EXCEDE LIMITE";
                    break;

                case "65":                          // Denegada, excede l�mite remanente de la tarjeta
                    message = "EXCEDE LIM. TARJETA";
                    break;

                case "76":                          // Solicitar autorizaci�n telef�nica
                    message = "LLAMAR AL EMISOR ERROR � DESC. PROD.";
                    break;

                case "77":                          // Denegada, cantidad de cuotas inv�lida para el plan seleccionado
                    message = "ERROR PLAN/CUOTAS� ERROR RECONCILIACI�N";
                    break;

                case "88":                          // Llamar al emisor
                    message = "CLIENTE LLAME";
                    break;

                case "89":                          // Denegada, n�mero de terminal no habilitado por el Emisor
                    message = "TERMINAL INVALIDA";
                    break;

                case "91":                          // Solo operaciones offline -> no aplica interprete
                    message = "EMISOR FUERA LINEA";
                    break;

                case "94":                          // Denegada. Error en mensaje.
                    message = "NRO. SEC. DUPLICAD";
                    break;

                case "95":                          // Diferencias en la conciliaci�n del cierre
                    message = "RE-TRANSMITIENDO";
                    break;

                case "96":                          // Mal funcionamiento del sistema.
                    message = "ERROR EN SISTEMA � MENSAJE INVALIDO";
                    break;

                case "BB":                          /**
                                                     * El host responde este codgo cuando la captura 
                                                     * de lote no esta disponible. EL terminal podr� 
                                                     * seguir operando pero no ser� posible efectuar el
                                                     * cierre de lote
                                                     **/
                    message = "COMP NO DISPONILE INTENTE MAS TARDE";
                    break;

                default:
                    message = "C�digo no mapeado, c�digo: " + hostResponseCode;
                    break;
            }
            return message;
        } 

        
    }
}
